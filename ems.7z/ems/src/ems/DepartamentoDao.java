package ems;

import java.util.ArrayList;

public class DepartamentoDao {

	static ArrayList<Departamento> departs = new ArrayList<Departamento>();
	
	public static void addDep(Departamento obj){
		departs.add(obj);
	}
	
	public static Departamento searchByName(String name){
		for(Departamento x: departs){
			if(x.getName().equals(name)){
				return x;
			}
		}
		return null;
	}
	
	public static Departamento searchById(int id){
		for(Departamento x: departs){
			if(x.getId() == id){
				return x;
			}
		}
		return null;
	}
	
	public static boolean addFunc(Funcionario x, int idDepa){
		for(Departamento r: departs){
			if(r.getId() == idDepa){
				r.addFunc(x);
				return true;
			}else{
				return false;
			}
		}
		return false;
	}
	
	public static Departamento listAll(String nameSearch){
		for(Departamento x: departs){
			if(x.getName().equals(nameSearch)){
				return x;
			}
		}
		return null;
	}
	
	public static Departamento searchUser(String nameSearch){
		for(Departamento x: departs){
			for(Funcionario y: x.getFuncionarios()){
				if(y.getName().equals(nameSearch)){
					return x;
				}
			}
		}
		return null;
	}
	
}
