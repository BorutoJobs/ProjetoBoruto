package ems;

public class Main {


	public static void main(String[] args) {
		int resp = 0;
		Funcionario objfunc = null;
		Departamento objdepa = null;
		do{
			
			System.out.println("Escolha uma op��o: \n 1- Cadastrar funcionario \n 2- Cadastrar departamento \n 3- Mover funcionario \n 4- Listar todos \n 5- Sair");
			resp = Console.readInt("> ");
			switch(resp){
			case 1:
				objfunc = new Funcionario();
				objfunc.setId(Console.readInt("Informe um ID: "));
				objfunc.setCpf(Console.readString("Informe o CPF: "));
				if(FuncionarioDao.searchByCpf(objfunc.getCpf()) != null){
					System.out.println("Este CPF j� esta cadastrado");
				}else{
				objfunc.setName(Console.readString("Informe seu nome"));
				if(FuncionarioDao.searchByName(objfunc.getName()) != null){
					System.out.println("Este nome j� esta cadastrado");
				}else{
					FuncionarioDao.addFunc(objfunc);
					System.out.println("Funcionario cadastrado");
				}
				}
			break;
			case 2:
				objdepa = new Departamento();
				objdepa.setId(Console.readInt("Informe um id para o departamento: "));
				if(DepartamentoDao.searchById(objdepa.getId()) != null){
					System.out.println("Este id ja esta sendo usado");
				}else{
				objdepa.setName(Console.readString("Informe o nome:"));
				if(DepartamentoDao.searchByName(objdepa.getName()) != null){
					System.out.println("Este departamento ja existe");
				}else{
					DepartamentoDao.addDep(objdepa);
				}
				}
			break;
			case 3:
				String userfind = Console.readString("Nome: ");
				Funcionario UserSearch = FuncionarioDao.searchByName(userfind);
				if(UserSearch == null){
					System.out.println("Usu�rio n�o encontrado");
				}else{
					int depaid = Console.readInt("ID departamento: ");
					if(DepartamentoDao.addFunc(UserSearch, depaid)){
						System.out.println("Usu�rio movido");
					}else{
						System.out.println("Departamento n�o encontrado");
					}
				}
			
			break;
			case 4:
				String depaFind = Console.readString("Dep Nome: ");
				for(Departamento x: DepartamentoDao.departs){
					if(DepartamentoDao.listAll(depaFind) != null){
					System.out.println("Dep: " + DepartamentoDao.listAll(depaFind).getName() + "\n ----------------------- \n Funcionarios \n --------------------------------- \n");
					for(Funcionario y: DepartamentoDao.listAll(depaFind).getFuncionarios()){
						System.out.println("Nome: " + y.getName());
					}
					}else{
						System.out.println("Departamento n�o encontrado!");
					}
					}
			
	
				
				
				break;
			case 5:
				String userFinder = Console.readString("Nome funcionario: ");
				Departamento searching = DepartamentoDao.searchUser(userFinder);
				if(searching == null){
					System.out.println("Usu�rio n�o encontrado");
				}else{
					System.out.println("Nome: " + searching.getName());
				}
			}
		}while(resp != 6);

	}

}
