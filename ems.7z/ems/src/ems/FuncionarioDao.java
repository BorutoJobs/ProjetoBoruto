package ems;

import java.util.ArrayList;

public class FuncionarioDao {

	static ArrayList<Funcionario> funcs = new ArrayList<Funcionario>();
	
	public static void addFunc(Funcionario obj){
		funcs.add(obj);
	}
	
	public static Funcionario searchByName(String name){
		for(Funcionario x: funcs){
			if(x.getName().equals(name)){
				return x;
			}
		}
		return null;
	}
	
	public static Funcionario searchByCpf(String cpf){
		for(Funcionario x: funcs){
			if(x.getCpf().equals(cpf)){
				return x;
			}
		}
		return null;
	}
	
}
