#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <locale.h>
#include <string.h>
#include <time.h>

//AQUI FICAM OS PROT�TIPOS DE TODAS AS FUN��ES CONTIDAS EM funcoes.c, QUE SER�O CHAMADAS NO MAIN
//SE A FUN��O RECEBER PARAMETROS, INCLUA-OS AQUI TAMB�M;

void menuPrincipal();
